import 'dart:ffi';

import 'package:flutter/material.dart';

class CadTrans extends StatelessWidget {
  Function addTrans;
  CadTrans(this.addTrans);

  var descricaoController = TextEditingController();
  var valorController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.blue,
        padding: EdgeInsets.all(10),
        child: Card(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 2),
          elevation: 5,
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              TextField(
                  controller: descricaoController,
                  decoration: InputDecoration(labelText: "Descrição")),
              TextField(
                  controller: valorController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: "Valor"),
                  onSubmitted: (_) => addTrans(descricaoController.text,
                      double.parse(valorController.text))),
              ElevatedButton(
                  onPressed: () {
                    addTrans(descricaoController.text,
                        double.parse(valorController.text));
                  },
                  child: Text('Incluir'))
            ]),
          ),
        ));
  }
}
