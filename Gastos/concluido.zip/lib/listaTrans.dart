import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'transacao.dart';

class ListaTrans extends StatelessWidget {
  List<Transacao> transacoes;
  Function delTransacao;
  ListaTrans(this.transacoes, this.delTransacao);

  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: ListView(
      children: transacoes.map((trans) {
        return Card(
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
              Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                  decoration: BoxDecoration(
                      border: Border.all(width: 2, color: Colors.purple)),
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'R\$ ${trans.valor.toStringAsFixed(2)}',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.purple),
                  )),
              Column(
                children: [
                  Text(
                    trans.descricao,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    DateFormat('dd-MM-yyyy HH:mm').format(trans.date),
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
              IconButton(
                  onPressed: () => delTransacao(trans.id),
                  icon: Icon(Icons.delete, color: Colors.red))
            ]));
      }).toList(),
    ));
  }
}
