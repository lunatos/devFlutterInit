class Transacao {
  int id;
  String descricao;
  double valor;
  DateTime date;
  Transacao(this.id, this.descricao, this.valor, this.date);
}
