import 'package:flutter/material.dart';
import 'transacao.dart';
import 'cadTrans.dart';
import 'listaTrans.dart';

class TransacaoController extends StatefulWidget {
  const TransacaoController({super.key});

  @override
  State<TransacaoController> createState() => _TransacaoControllerState();
}

class _TransacaoControllerState extends State<TransacaoController> {
  List<Transacao> transacoes = [
    Transacao(1, "Café", 3.00, DateTime.now()),
    Transacao(2, "Pão de Queijo", 3.00, DateTime.now()),
    Transacao(3, "Queijo", 5.00, DateTime.now())
  ];
  void addTransacao(String descricao, double valor) {
    Transacao nova =
        Transacao(transacoes.length + 1, descricao, valor, DateTime.now());
    setState(() {
      transacoes.add(nova);
    });
  }

  void delTransacao(int id) {
    setState(() {
      transacoes.removeWhere((transacao) => transacao.id == id);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [CadTrans(addTransacao), ListaTrans(transacoes, delTransacao)],
    );
  }
}
